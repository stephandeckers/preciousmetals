﻿/**
 * @Name DiagnosticsWriter.cs
 * @Purpose 
 * @Date 19 March 2021, 07:47:01
 * @Author S.Deckers
 * @Description 
 */

namespace Nop.Plugin.Pricing.PreciousMetals.Helpers
{
	#region -- Using directives --
	using System;
	#endregion
	
	internal class DiagnosticsWriter
	{
		internal static void WriteLine( string s)
		{
			//System.Diagnostics.Debug.WriteLine( s);
		}
	}
}
