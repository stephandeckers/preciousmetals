﻿/**
 * @Name PreciousMetalsQuoteService.cs
 * @Purpose 
 * @Date 12 January 2021, 19:04:45
 * @Author S.Deckers
 * @Description 
 */

namespace Nop.Plugin.Pricing.PreciousMetals.Services
{
	#region -- Using directives --
	using System;
	using System.Linq;

	using Nop.Core;
	using Nop.Data;
	using Nop.Core.Caching;
	using Nop.Services.Caching;
	using Nop.Services.Caching.Extensions;
	using Nop.Core.Domain.Logging;
	using Nop.Core.Domain.Configuration;
	using Nop.Services.Logging;	
	using Nop.Services.Configuration;	

	using Nop.Plugin.Pricing.PreciousMetals.Domain;
	using Nop.Plugin.Pricing.PreciousMetals.Providers;

	//using d=System.Diagnostics.Debug;
	using d=Nop.Plugin.Pricing.PreciousMetals.Helpers.DiagnosticsWriter;
	#endregion

	/// <summary date="23-01-2021, 07:17:02" author="S.Deckers">
	/// IPreciousMetalsQuoteService
	/// </summary>
    public interface IPreciousMetalsQuoteService
    {
        PreciousMetalsQuote GetQuote				( PreciousMetalType metalType);
        PreciousMetalsQuote	GetKitcoGoldQuote		( );
		PreciousMetalsQuote	GetKitcoSilverQuote		( );
		PreciousMetalsQuote	GetxIgniteGoldQuote		( );
		PreciousMetalsQuote	GetxIgniteSilverQuote	( );
		void				InsertQuote				( PreciousMetalsQuote preciousMetalsQuote);
    }

	/// <summary date="23-01-2021, 07:17:06" author="S.Deckers">
	/// PreciousMetalsQuoteService
	/// </summary>
	public partial class PreciousMetalsQuoteService : IPreciousMetalsQuoteService
	{
		private readonly ILogger							_logger;
		private readonly IStaticCacheManager				_staticCacheManager;
		private readonly IRepository<PreciousMetalsQuote>	_repository;
		private readonly PreciousMetalsSettings				_preciousMetalsSettings;

		/// <summary date="14-01-2021, 22:07:56" author="S.Deckers">
		/// Construction
		/// </summary>
		/// <param name="logger"></param>
		/// <param name="settingService"></param>
		/// <param name="repository"></param>
		public PreciousMetalsQuoteService
		( 
			ILogger								logger
		,	IStaticCacheManager					staticCacheManager
		,	IRepository<PreciousMetalsQuote>	repository
		,	PreciousMetalsSettings				preciousMetalsSettings
		)
		{ 
			d.WriteLine( string.Format( "{0}.{1} ({2}.{3}):{4}", GetType().Name, System.Reflection.MethodInfo.GetCurrentMethod( ).Name, System.Threading.Thread.CurrentThread.ManagedThreadId, Global.CallCount++, string.Empty));

			this._logger					= logger;
			this._staticCacheManager		= staticCacheManager;
			this._repository				= repository;
			this._preciousMetalsSettings	= preciousMetalsSettings;
		}

		/// <summary date="13-01-2021, 18:18:04" author="S.Deckers">
		/// GetQuote
		/// </summary>
		/// <param name="metalType"></param>
		/// <returns></returns>
		public PreciousMetalsQuote GetQuote( PreciousMetalType metalType)
		{
			d.WriteLine( string.Format( "{0}.{1} ({2}.{3}):{4}", GetType( ).Name, System.Reflection.MethodInfo.GetCurrentMethod( ).Name, System.Threading.Thread.CurrentThread.ManagedThreadId, Global.CallCount++, string.Empty ) );

			this._logger.InsertLog( LogLevel.Information, GetType( ).Name, string.Format( "metalType={0}", metalType), null);

			return( handle_GetQuote( metalType));
		}

		/// <summary date="15-01-2021, 12:03:25" author="S.Deckers">
		/// GetxIgniteGoldQuote
		/// </summary>
		/// <returns></returns>
		public PreciousMetalsQuote GetxIgniteGoldQuote( )
		{
			d.WriteLine( string.Format( "{0}.{1} ({2}.{3}):{4}", GetType().Name, System.Reflection.MethodInfo.GetCurrentMethod( ).Name, System.Threading.Thread.CurrentThread.ManagedThreadId, Global.CallCount++, string.Empty));

			this._logger.InsertLog( Nop.Core.Domain.Logging.LogLevel.Information, GetType().Name, "Getting Quote", null);
			return( getxIgniteQuoteFromInternet( PreciousMetalType.Gold));
		}

		/// <summary date="15-01-2021, 12:03:28" author="S.Deckers">
		/// GetxIgniteSilverQuote
		/// </summary>
		/// <returns></returns>
		public PreciousMetalsQuote GetxIgniteSilverQuote( )
		{
			d.WriteLine( string.Format( "{0}.{1} ({2}.{3}):{4}", GetType().Name, System.Reflection.MethodInfo.GetCurrentMethod( ).Name, System.Threading.Thread.CurrentThread.ManagedThreadId, Global.CallCount++, string.Empty));

			this._logger.InsertLog( Nop.Core.Domain.Logging.LogLevel.Information, GetType().Name, "Getting Quote", null);
			return( getxIgniteQuoteFromInternet( PreciousMetalType.Silver));
		}

		/// <summary date="13-01-2021, 18:17:11" author="S.Deckers">
		/// GetKitcoGoldQuote
		/// </summary>
		/// <returns></returns>
		public PreciousMetalsQuote GetKitcoGoldQuote ( )
		{
			d.WriteLine( string.Format( "{0}.{1} ({2}.{3}):{4}", GetType().Name, System.Reflection.MethodInfo.GetCurrentMethod( ).Name, System.Threading.Thread.CurrentThread.ManagedThreadId, Global.CallCount++, string.Empty));

			this._logger.InsertLog( Nop.Core.Domain.Logging.LogLevel.Information, GetType().Name, "Getting Quote", null);
			return( getKitcoQuoteFromInternet( PreciousMetalType.Gold));
		}

		/// <summary date="13-01-2021, 18:17:08" author="S.Deckers">
		/// GetKitcoSilverQuote
		/// </summary>
		/// <returns></returns>
		public PreciousMetalsQuote GetKitcoSilverQuote ( )
		{
			d.WriteLine( string.Format( "{0}.{1} ({2}.{3}):{4}", GetType().Name, System.Reflection.MethodInfo.GetCurrentMethod( ).Name, System.Threading.Thread.CurrentThread.ManagedThreadId, Global.CallCount++, string.Empty));

			this._logger.InsertLog( Nop.Core.Domain.Logging.LogLevel.Information, GetType().Name, "Getting Quote", null);
			return( getKitcoQuoteFromInternet( PreciousMetalType.Silver));
		}

		/// <summary date="14-01-2021, 22:10:22" author="S.Deckers">
		/// Store quote in DB
		/// </summary>
		/// <param name="preciousMetalsQuote"></param>
		public void	InsertQuote( PreciousMetalsQuote preciousMetalsQuote)
		{
			d.WriteLine( string.Format( "{0}.{1} ({2}.{3}):{4}", GetType().Name, System.Reflection.MethodInfo.GetCurrentMethod( ).Name, System.Threading.Thread.CurrentThread.ManagedThreadId, Global.CallCount++, string.Empty));
			_repository.Insert( preciousMetalsQuote);
		}
	}

	public partial class PreciousMetalsQuoteService
	{
		/// <summary date="15-01-2021, 12:03:37" author="S.Deckers">
		/// getxIgniteQuote
		/// </summary>
		/// <param name="metalType"></param>
		/// <returns></returns>
		private PreciousMetalsQuote handle_GetQuoteX( PreciousMetalType metalType)
		{
			d.WriteLine( string.Format( "{0}.{1} ({2}.{3}):{4}", GetType().Name, System.Reflection.MethodInfo.GetCurrentMethod( ).Name, System.Threading.Thread.CurrentThread.ManagedThreadId, Global.CallCount++, string.Empty));

			this._logger.InsertLog( Nop.Core.Domain.Logging.LogLevel.Information, GetType().Name, "Getting Quote", null);

			CacheKey key = new CacheKey( string.Format( "pricing.preciousMetals.id.{0}", metalType));

			//CachePeriodInMinutes
			//int quoteProvider = this._preciousMetalsSettings.QuoteProvider;
			int cachePeriodInMinutes = this._preciousMetalsSettings.CachePeriodInMinutes;

			return( this._staticCacheManager.Get(key, ( ) =>
			{
				//const int cachePeriodInMinutes = 5;
				//const int cachePeriodInMinutes = 1;
                // get the last quote from the database that is within our cache time
                DateTime			earliestValidCacheTime = DateTime.Now.AddMinutes(- cachePeriodInMinutes);
                PreciousMetalsQuote quote = _repository.Table
                    .Where(q => q.MetalType == metalType && q.DateRetrieved >= earliestValidCacheTime)
					.Where(q => q.MetalType == metalType)
                    .OrderByDescending(q => q.DateRetrieved).FirstOrDefault();

                // if nothing current is in the database, look online.
                if( quote == null)
				{
					this._logger.InsertLog( Nop.Core.Domain.Logging.LogLevel.Information, "F1", "No quote read from database", null);
					quote = getQuoteFromInternet( metalType);
					_repository.Insert( quote);
				}
				// return the quote
                return quote;
			}));
		}

		private const string CACHE_KEY = "pricing.preciousMetals.id.{0}";

		//public static string PrefixCacheKey => "Nop.Plugin.Widgets.FacebookPixel";

		private PreciousMetalsQuote handle_GetQuote( PreciousMetalType metalType)
		{
			d.WriteLine( string.Format( "{0}.{1} ({2}.{3}):{4}", GetType().Name, System.Reflection.MethodInfo.GetCurrentMethod( ).Name, System.Threading.Thread.CurrentThread.ManagedThreadId, Global.CallCount++, string.Empty));

			string s = string.Empty;

			int cachePeriodInMinutes = this._preciousMetalsSettings.CachePeriodInMinutes;

			// - if cachetime is zero always fetch
			// - get real price
			s = string.Format( "Evaluating cache, date={0:hh:mm:ss}, cachePeriod={1}", System.DateTime.Now, cachePeriodInMinutes);
			//d.WriteLine( s);
			this._logger.InsertLog( Nop.Core.Domain.Logging.LogLevel.Information, GetType().Name, s, null);			
		
			string		key = string.Format( "pricing.preciousMetals.id.{0}", metalType);
			CacheKey	cacheKey = new CacheKey( key, cacheTime: cachePeriodInMinutes);

			//_staticCacheManager.RemoveByPrefix( "pricing.preciousMetals.id.*");
			//_cacheManager.Clear();

			//_staticCacheManager.Clear();

            return _staticCacheManager.Get(cacheKey,  () =>
            {
				//s = string.Format( "quote out of cachetime:[{0:hh:mm:ss}]= [{1:hh:mm:ss}]", quote.DateRetrieved, earliestValidCacheTime);
				s = string.Format( "Cache invalid, date={0:hh:mm:ss}, cachePeriod={1}", System.DateTime.Now, cachePeriodInMinutes);
				d.WriteLine( s);
				this._logger.InsertLog( Nop.Core.Domain.Logging.LogLevel.Information, GetType().Name, s, null);

				//this._logger.InsertLog( Nop.Core.Domain.Logging.LogLevel.Information, GetType().Name, "Cache invalid", null);

				PreciousMetalsQuote quote = getQuoteFromInternet(metalType);
				_repository.Insert( quote);
				s = string.Format( "Cache refreshed,id={0}", quote.Id);
				//d.WriteLine( s);
				this._logger.InsertLog( Nop.Core.Domain.Logging.LogLevel.Information, GetType().Name, s, null);
				return( quote);
			});
		}

		private PreciousMetalsQuote handle_GetQuote_v3( PreciousMetalType metalType)
		{
			d.WriteLine( string.Format( "{0}.{1} ({2}.{3}):{4}", GetType().Name, System.Reflection.MethodInfo.GetCurrentMethod( ).Name, System.Threading.Thread.CurrentThread.ManagedThreadId, Global.CallCount++, string.Empty));

			this._logger.InsertLog( Nop.Core.Domain.Logging.LogLevel.Information, GetType().Name, "evaluating cache", null);

			int cachePeriodInMinutes = this._preciousMetalsSettings.CachePeriodInMinutes;

			cachePeriodInMinutes = 1;

			string		theCacheKey = string.Format( "pricing.preciousMetals.id.{0}", metalType);
			CacheKey	cachedQuote = new CacheKey( theCacheKey, cacheTime: cachePeriodInMinutes);
			//CacheKey	cachedQuote = new CacheKey( theCacheKey, cacheTime: null);

            return _staticCacheManager.Get(cachedQuote,  () =>
            {
                //DateTime			earliestValidCacheTime	= DateTime.Now.AddMinutes(- cachePeriodInMinutes);
                PreciousMetalsQuote	quote = _repository.Table
											//.Where(q => q.MetalType == metalType && q.DateRetrieved >= earliestValidCacheTime)
											.Where(q => q.MetalType == metalType)
											.OrderByDescending(q => q.DateRetrieved).FirstOrDefault();
				string s = string.Empty;

				// --- Nothing current in database, fetch new quote (20210123 SDE)

				if( quote == null)
				{
					//s = string.Format( "No quote read, fetching new one");
					//d.WriteLine( s);

					this._logger.InsertLog( Nop.Core.Domain.Logging.LogLevel.Information, GetType().Name, s, null);

					quote = getQuoteFromInternet(metalType);
					_repository.Insert( quote);
					return( quote);
				}

				// --- Quote read, check Cache (20210123 SDE)

				//DateTime earliestValidCacheTime	= DateTime.Now.AddMinutes(- cachePeriodInMinutes);
				DateTime earliestValidCacheTime	= DateTime.Now.AddSeconds( -30);

				s = string.Format( "quote read, DateRetrieved={0:hh:mm:ss}, earliestValidCacheTime={1:hh:mm:ss}, cachePeriod={2}", quote.DateRetrieved, earliestValidCacheTime, cachePeriodInMinutes);

				//d.WriteLine( s);

				this._logger.InsertLog( Nop.Core.Domain.Logging.LogLevel.Information, GetType().Name, s, null);
					
				// --- Quote within Cachetime (20210123 SDE)

				if( quote.DateRetrieved >= earliestValidCacheTime)
				{
					s = string.Format( "quote within cachetime:[{0:hh:mm:ss}] >= [{1:hh:mm:ss}]", quote.DateRetrieved, earliestValidCacheTime);
					this._logger.InsertLog( Nop.Core.Domain.Logging.LogLevel.Information, GetType().Name, s, null);
					return( quote);
				}

				// --- Quote outdated (20210123 SDE)

				//s = string.Format( "quote within cachetime:[{0:hh:mm:ss}] < [{1:hh:mm:ss}], fetching new", quote.DateRetrieved, earliestValidCacheTime);
				//d.WriteLine( s);
				this._logger.InsertLog( Nop.Core.Domain.Logging.LogLevel.Information, GetType().Name, s, null);

				quote = getQuoteFromInternet(metalType);
				_repository.Insert( quote);	
				return( quote);
            });
		}

		//private PreciousMetalsQuote handle_GetQuoteDBG( PreciousMetalType metalType)
		//{
		//	d.WriteLine( string.Format( "{0}.{1} ({2}.{3}):{4}", GetType().Name, System.Reflection.MethodInfo.GetCurrentMethod( ).Name, System.Threading.Thread.CurrentThread.ManagedThreadId, Global.CallCount++, string.Empty));

		//	//static PreciousMetalsQuote f1( PreciousMetalType theType)
		//	//{
		//	//	return( null);
		//	//}

		//	static string GetMessage1() { return "Hello world"; }

		//	this._logger.InsertLog( Nop.Core.Domain.Logging.LogLevel.Information, GetType().Name, "Getting Quote", null);

		//	CacheKey cacheKey = new CacheKey( string.Format( "pricing.preciousMetals.id.{0}", metalType));

		//	int cachePeriodInMinutes = this._preciousMetalsSettings.CachePeriodInMinutes;
		//	cachePeriodInMinutes = 1;
			
		//	PreciousMetalsQuote quote = null;
		//	//quote = this._staticCacheManager.Get( key:cacheKey, acquire:f1( theType:metalType));
		//	//quote = this._staticCacheManager.Get( cacheKey, f1);
		//	 this._staticCacheManager.Get( cacheKey, GetMessage);
		//	this._staticCacheManager.Get( cacheKey, GetMessage1);
		//	//this._staticCacheManager.Get( cacheKey, GetQuote);
		//	//this._staticCacheManager.Get( cacheKey, GetQuoteWithArgs( metalType));

		//	return( quote);
		//}

		//public static string GetMessage() { return "Hello world"; }
		//public static PreciousMetalsQuote GetQuote() { return null; }
		//public static PreciousMetalsQuote GetQuoteWithArgs(PreciousMetalType metalType) { return null; }

		/// <summary date="15-01-2021, 12:04:01" author="S.Deckers">
		/// getQuoteFromInternet
		/// </summary>
		/// <param name="metalType"></param>
		/// <returns></returns>
		private PreciousMetalsQuote getQuoteFromInternet( PreciousMetalType metalType)
		{
			d.WriteLine( string.Format( "{0}.{1} ({2}.{3}):{4}", GetType().Name, System.Reflection.MethodInfo.GetCurrentMethod( ).Name, System.Threading.Thread.CurrentThread.ManagedThreadId, Global.CallCount++, string.Empty));

			this._logger.InsertLog( Nop.Core.Domain.Logging.LogLevel.Information, GetType().Name, string.Format( "Getting Quote for {0}", metalType), null);

			QuoteProvider quoteProvider = this._preciousMetalsSettings.QuoteProvider;

			switch( quoteProvider)
			{
				// --- Get quote from xIgnite (20210115 SDE)

				case( QuoteProvider.xIgnite):
				{
					if( metalType == PreciousMetalType.Gold)
					{
						return( getxIgniteQuoteFromInternet( PreciousMetalType.Gold));
					}

					if( metalType == PreciousMetalType.Silver)
					{
						return( getxIgniteQuoteFromInternet( PreciousMetalType.Silver));
					}

					this._logger.Error( string.Format( "Unsupported metalType:{0}", metalType));
					return( null);
				}

				// --- Get quote from Kitco (20210115 SDE)

				case( QuoteProvider.Kitco):
				{
					if( metalType == PreciousMetalType.Gold)
					{							
						return( getKitcoQuoteFromInternet( PreciousMetalType.Gold));
					}

					if( metalType == PreciousMetalType.Silver)
					{
						return( getKitcoQuoteFromInternet( PreciousMetalType.Silver));
					}

					this._logger.Error( string.Format( "Unsupported metalType:{0}", metalType));
					return( null);
				}

				// --- Can't handle this (20210115 SDE)

				default:
				{
					this._logger.Error( string.Format( "Unsupported QuoteProvider:{0}", quoteProvider));
					return( null);
				}
			}
		}

		/// <summary date="15-01-2021, 12:05:42" author="S.Deckers">
		/// getxIgniteQuoteFromInternet 
		/// </summary>
		/// <param name="metalType"></param>
		/// <returns></returns>
		private PreciousMetalsQuote getxIgniteQuoteFromInternet( PreciousMetalType metalType)
		{
			d.WriteLine( string.Format( "{0}.{1} ({2}.{3}):{4}", GetType().Name, System.Reflection.MethodInfo.GetCurrentMethod( ).Name, System.Threading.Thread.CurrentThread.ManagedThreadId, Global.CallCount++, string.Empty));

			this._logger.InsertLog( Nop.Core.Domain.Logging.LogLevel.Information, GetType().Name, "Getting Quote", null);

			string xIgniteToken = this._preciousMetalsSettings.xIgniteToken;
			string errMsg;
			PreciousMetalsQuote q = xIgniteQuoteProvider.GetQuote( metalType, xIgniteToken, xIgniteQuoteProvider.xIgniteCurrency.Euro, out errMsg);			

			if( string.IsNullOrEmpty( errMsg) == false)
			{ 
				this._logger.Error( string.Format( "{0}:{1}", GetType().Name, errMsg));
				return( null);
			}

			this._logger.InsertLog( Nop.Core.Domain.Logging.LogLevel.Information, GetType().Name, string.Format( "Quote received:Ask={0}, Bid={1}", q.Ask, q.Bid), null);
			q.Provider = "xIgnite";			
			return( q);
		}

		/// <summary date="15-01-2021, 12:08:44" author="S.Deckers">
		/// getKitcoQuoteFromInternet
		/// </summary>
		/// <param name="metalType"></param>
		/// <returns></returns>
		private PreciousMetalsQuote getKitcoQuoteFromInternet( PreciousMetalType metalType)
		{
			d.WriteLine( string.Format( "{0}.{1} ({2}.{3}):{4}", GetType().Name, System.Reflection.MethodInfo.GetCurrentMethod( ).Name, System.Threading.Thread.CurrentThread.ManagedThreadId, Global.CallCount++, string.Empty));

			this._logger.InsertLog( Nop.Core.Domain.Logging.LogLevel.Information, GetType().Name, "Getting Quote", null);

			string errMsg;
			PreciousMetalsQuote q = KitcoQuoteProvider.GetQuote( metalType, out errMsg);

			if( string.IsNullOrEmpty( errMsg) == false)
			{ 
				this._logger.Error( string.Format( "{0}:{1}", GetType().Name, errMsg));
				return( null);
			}

			this._logger.InsertLog( Nop.Core.Domain.Logging.LogLevel.Information, GetType().Name, string.Format( "Quote received:Ask={0}, Bid={1}", q.Ask, q.Bid), null);
			q.Provider = "Kitco";			
			return( q);
		}
	}
}

